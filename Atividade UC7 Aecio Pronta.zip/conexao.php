<?php
$servername = "localhost";
$database = "contatos"; // nome do banco de dados criado.
$username = "root";
$password = "";
//cria a conexão
$conexao= mysqli_connect($servername, $username, $password, $database);
?>